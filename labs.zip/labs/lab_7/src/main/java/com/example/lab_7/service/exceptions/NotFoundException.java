package com.example.lab_7.service.exceptions;


public class NotFoundException extends Exception{
    public NotFoundException(String message) {
        super(message);
    }
}
