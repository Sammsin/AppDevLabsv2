package ie.spring.jdbc.configurations.daos.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cartoon {
    private int cartoonId;
    private String cartoonName;
    private int firstAppearanceYear;

    public Cartoon(int cartoonId, String cartoonName, int firstAppearanceYear){
        this.cartoonId = cartoonId;
        this.cartoonName = cartoonName;
        this.firstAppearanceYear = firstAppearanceYear;
    }
}