package ie.spring.jdbc.configurations;

import ie.spring.jdbc.configurations.daos.dtos.Cartoon;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import javax.naming.Name;
import java.util.List;

@Repository
@AllArgsConstructor
public class CartoonRepoImplementation extends CartoonRepo {
    private JdbcTemplate jdbcTemplate;

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public Cartoon cartoon save(Cartoon cartoon){
        SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcTemplate)
                .withTableName("cartoons")
                .usingGeneratedKeyColumns("cartoon_id");

        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValues("cartoon_name", cartoon.getCartoonName());
        params.addValues("first_appearance", cartoon.getFirstAppearanceYear())
        int pk = simpleJdbcInsert.executeAndReturnKey(params).intValue();
        cartoon.setCartoonId(pk);
        return cartoon;
    }

    @Override
    public List<Name> getCartoonsNames() {
        String sql = "SELECT cartoon_name FROM cartoons cartoon";
        return jdbcTemplate.query(sql, new NameCartoonMapper());
    }

}
