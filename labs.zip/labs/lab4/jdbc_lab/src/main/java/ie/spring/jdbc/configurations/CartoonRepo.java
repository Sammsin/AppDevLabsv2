package ie.spring.jdbc.configurations;

public class CartoonRepo {
    int count
}
