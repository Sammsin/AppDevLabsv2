package ie.spring.jdbc.configurations;

import org.springframework.jdbc.core.RowMapper;

import javax.lang.model.element.Name;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NameCartoonMapper implements RowMapper<Name> {
    @Override
    public Name mapRow(ResultSet rs, int rowNum) throws SQLException {
        return new Name(rs.getString(""))
    }
}
