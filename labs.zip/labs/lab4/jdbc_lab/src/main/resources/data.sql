INSERT INTO cartoons (cartoon_id, cartoon_name, first_appearance_year)
VALUES
    (1,'SpongeBob SquarePants', 1999),
    (2,'Pikachu', 1996),
    (3,'Dora the Explorer', 2000),
    (4,'Pac-Man', 1980),
    (5,'Teenage Mutant Ninja Turtles', 1987),
    (6,'Inspector Gadget', 1983),
    (7,'He-Man', 1983),
    (8,'ThunderCats', 1985),
    (9,'Care Bears', 1985),
    (10,'Transformers', 1984);