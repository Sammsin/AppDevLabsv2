package ie.spring.lab1;

import ie.spring.lab1.repositories.weddings.MockWeddingRepositoryImpl;
import ie.spring.lab1.repositories.weddings.WeddingRepository;
import ie.spring.lab1.repositories.weddings.MockWeddingRepositoryImpl;
import ie.spring.lab1.repositories.weddings.WeddingRepository;
import ie.spring.lab1.repositories.weddings.Wedding;
import ie.spring.lab1.services.CalculateCost;
import ie.spring.lab1.services.CalculateCostImplementation;

public class MainApp {
    public static void main(String[] args)  {

        WeddingRepository weddingRepository = new MockWeddingRepositoryImpl();
        Wedding wedding = weddingRepository.findById("RS342").orElseThrow(() -> new RuntimeException("Wedding not found"));
        System.out.println(wedding);

        CalculateCost calculateCost = new CalculateCostImplementation(weddingRepository);

        try {
            double costExVat = calculateCost.calculateWeddingCostExVat("RS342");
            double costIncVat = calculateCost.calculateWeddingCostIncVat("RS342");

            System.out.println("Cost Excluding VAT: " + costExVat);
            System.out.println("Cost Including VAT: " + costIncVat);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }

    }
    public void id(){
        WeddingRepository weddingRepository = new MockWeddingRepositoryImpl();

    }
}
