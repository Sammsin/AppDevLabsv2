package ie.spring.jdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

public class DemoApplication {

    public static void main(String[] args) {
        ApplicationContext applicationContext = new SpringApplication(DemoApplication.class).run(args);
    }

}
