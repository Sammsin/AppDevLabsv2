CREATE TABLE cartoons (
 cartoon_id INT PRIMARY KEY,
 cartoon_name VARCHAR(255) NOT NULL,
 first_appearance_year INT
);